import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';

/**
 * Página de inicio (/).
 * Si el usuario está logueado → lo manda al dashboard.
 * Si no está logueado → lo manda al login.
 */
export default async function HomePage() {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (user) {
    redirect('/dashboard');
  } else {
    redirect('/login');
  }
}
